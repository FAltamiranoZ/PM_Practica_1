#!/usr/bin/env python

import rospy
import time
import sys
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose

def poseCallback(pose_message):

    global theta
    theta = pose_message.theta

def move_circle(radius):
    global theta

    rospy.init_node('move_circle', anonymous=True)
    pub = rospy.Publisher('turtle1/cmd_vel', Twist, queue_size=1)
    move_cmd = Twist()
    move_cmd.linear.x = radius
    move_cmd.angular.z = 1.0
    now = rospy.Time.now()
    rate = rospy.Rate(60)

    while True:
        print ('angulo=', theta)
        if (theta <  1.0 and theta > 0.565 and rospy.Time.now() > now + rospy.Duration.from_sec(2)):
            break
        pub.publish(move_cmd)
        rate.sleep()

def move_circle2(radius):
    global theta

    rospy.init_node('move_circle', anonymous=True)
    pub = rospy.Publisher('turtle1/cmd_vel', Twist, queue_size=1)
    move_cmd = Twist()
    move_cmd.linear.x = -radius
    move_cmd.angular.z = -1.0
    now = rospy.Time.now()
    rate = rospy.Rate(60)

    while True:
        print ('angulo=', theta)
        if (theta <  2.575 and theta > 2.0 and rospy.Time.now() > now + rospy.Duration.from_sec(2)):
            break
        pub.publish(move_cmd)
        rate.sleep()

if __name__ == '__main__':
    try:
        position_topic = "/turtle1/pose"
        pose_subscriber = rospy.Subscriber(position_topic, Pose, poseCallback)
	if (float(sys.argv[2]) == 1):
	    move_circle(float(sys.argv[1]))
        if (float(sys.argv[2]) == 2):
	    move_circle2(float(sys.argv[1]))
    except rospy.ROSInterruptException:
        pass


