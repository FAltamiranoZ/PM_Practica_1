#!/usr/bin/env python  
import roslib
roslib.load_manifest('learning_tf')
import rospy
import math
import tf
import geometry_msgs.msg
import turtlesim.srv
from turtlesim.msg import Pose


def poseCallback1(pose_message):
    global x1
    global y1
    x1 = pose_message.x
    y1 = pose_message.y

def poseCallback2(pose_message):
    global x2
    global y2
    
    x2 = pose_message.x
    y2 = pose_message.y

def poseCallback3(pose_message):
    global x3
    global y3
    
    x3 = pose_message.x
    y3 = pose_message.y

def poseCallback4(pose_message):
    global x4
    global y4
    
    x4 = pose_message.x
    y4 = pose_message.y

def poseCallback5(pose_message):
    global x5
    global y5
    
    x5 = pose_message.x
    y5 = pose_message.y

def poseCallback6(pose_message):
    global x6
    global y6
    
    x6 = pose_message.x
    y6 = pose_message.y

if __name__ == '__main__':
    rospy.init_node('turtle_tf_listener')
    listener = tf.TransformListener()

    rospy.wait_for_service('spawn')
    spawner = rospy.ServiceProxy('spawn', turtlesim.srv.Spawn)
    spawner(4, 2, 0, 'turtle2')
    spawner(8.5, 5.45, 0, 'turtle3')
    spawner(6.5, 7.45, 0, 'turtle4')
    spawner(4.5, 3.45, 0, 'turtle5')
    spawner(8.5, 6.45, 0, 'turtle6') 

    turtle_vel = rospy.Publisher('turtle2/cmd_vel', geometry_msgs.msg.Twist,queue_size=1)
    position_topic1 = "/turtle1/pose"
    pose_subscriber = rospy.Subscriber(position_topic1, Pose, poseCallback1)
    position_topic2 = "/turtle2/pose"
    pose_subscriber = rospy.Subscriber(position_topic2, Pose, poseCallback2)
    position_topic3 = "/turtle3/pose"
    pose_subscriber = rospy.Subscriber(position_topic3, Pose, poseCallback3)
    position_topic4 = "/turtle4/pose"
    pose_subscriber = rospy.Subscriber(position_topic4, Pose, poseCallback4)
    position_topic5 = "/turtle5/pose"
    pose_subscriber = rospy.Subscriber(position_topic5, Pose, poseCallback5)
    position_topic6 = "/turtle6/pose"
    pose_subscriber = rospy.Subscriber(position_topic6, Pose, poseCallback6)

    global x1
    global y1
    global x2
    global y2
    global x3
    global y3
    global x4
    global y4
    global x5
    global y5
    global x6
    global y6

    rate = rospy.Rate(60.0)
    while not rospy.is_shutdown():
        try:
            (trans,rot) = listener.lookupTransform('/turtle2', '/carrot1', rospy.Time(0))
	    (trans1,rot1) = listener.lookupTransform('/turtle2', '/turtle1', rospy.Time(0))
	    (trans2,rot2) = listener.lookupTransform('/turtle2', '/turtle3', rospy.Time(0))
	    (trans3,rot3) = listener.lookupTransform('/turtle2', '/turtle4', rospy.Time(0))
	    (trans4,rot4) = listener.lookupTransform('/turtle2', '/turtle5', rospy.Time(0))
	    (trans5,rot5) = listener.lookupTransform('/turtle2', '/turtle6', rospy.Time(0))
        except (tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
            continue

	medidor1 = math.sqrt(trans1[0] ** 2 + trans1[1] ** 2)
	medidor2 = math.sqrt(trans2[0] ** 2 + trans2[1] ** 2)
	medidor3 = math.sqrt(trans3[0] ** 2 + trans3[1] ** 2)
	medidor4 = math.sqrt(trans4[0] ** 2 + trans4[1] ** 2)
	medidor5 = math.sqrt(trans5[0] ** 2 + trans5[1] ** 2)

	cont = 0
	if (medidor1 < 1.5):
	    cont = cont + 1
	if (medidor2 < 1.5):
	    cont = cont + 1
	if (medidor3 < 1.5):
	    cont = cont + 1
	if (medidor4 < 1.5):
	    cont = cont + 1
	if (medidor5 < 1.5):
	    cont = cont + 1

	if (cont > 1):
	    linear = -math.sqrt(trans[0] ** 2 + trans[1] ** 2)/2
	    angular = 4 * math.atan2(trans[1], trans[0])
	if (cont > 0):
	    if (medidor1 < 1.5):
		if (x1 < x2): 
		    linear = math.sqrt(trans[0] ** 2 + trans[1] ** 2)/1.5
                    angular = 4 * (math.atan2(trans[1], trans[0]) - (1/abs(math.sqrt(((x1-x2)**2)+((y1-y2)**2)))))
	    	else: 
	            linear = math.sqrt(trans[0] ** 2 + trans[1] ** 2)/2
                    angular = 4 * (math.atan2(trans[1], trans[0]) + (1/abs(math.sqrt(((x1-x2)**2)+((y1-y2)**2)))))
	    if (medidor2 < 1.5):
		if (x3 < x2): 
		    linear = math.sqrt(trans[0] ** 2 + trans[1] ** 2)/1.5
                    angular = 4 * (math.atan2(trans[1], trans[0]) - (1/abs(math.sqrt(((x3-x2)**2)+((y3-y2)**2)))))
	    	else: 
	            linear = math.sqrt(trans[0] ** 2 + trans[1] ** 2)/2
                    angular = 4 * (math.atan2(trans[1], trans[0]) + (1/abs(math.sqrt(((x3-x2)**2)+((y3-y2)**2)))))
	    if (medidor3 < 1.5):
		if (x4 < x2): 
		    linear = math.sqrt(trans[0] ** 2 + trans[1] ** 2)/1.5
                    angular = 4 * (math.atan2(trans[1], trans[0]) - (1/abs(math.sqrt(((x4-x2)**2)+((y4-y2)**2)))))
	    	else: 
	            linear = math.sqrt(trans[0] ** 2 + trans[1] ** 2)/2
                    angular = 4 * (math.atan2(trans[1], trans[0]) + (1/abs(math.sqrt(((x4-x2)**2)+((y4-y2)**2)))))
	    if (medidor4 < 1.5):
		if (x5 < x2): 
		    linear = math.sqrt(trans[0] ** 2 + trans[1] ** 2)/1.5
                    angular = 4 * (math.atan2(trans[1], trans[0]) - (1/abs(math.sqrt(((x5-x2)**2)+((y5-y2)**2)))))
	    	else: 
	            linear = math.sqrt(trans[0] ** 2 + trans[1] ** 2)/2
                    angular = 4 * (math.atan2(trans[1], trans[0]) + (1/abs(math.sqrt(((x5-x2)**2)+((y5-y2)**2)))))
	    if (medidor5 < 1.5):
		if (x6 < x2): 
		    linear = math.sqrt(trans[0] ** 2 + trans[1] ** 2)/1.5
                    angular = 4 * (math.atan2(trans[1], trans[0]) - (1/abs(math.sqrt(((x6-x2)**2)+((y6-y2)**2)))))
	    	else: 
	            linear = math.sqrt(trans[0] ** 2 + trans[1] ** 2)/2
                    angular = 4 * (math.atan2(trans[1], trans[0]) + (1/abs(math.sqrt(((x6-x2)**2)+((y6-y2)**2)))))
	else: 
	    linear = math.sqrt(trans[0] ** 2 + trans[1] ** 2)/2
            angular = 4 * math.atan2(trans[1], trans[0])

        cmd = geometry_msgs.msg.Twist()
        cmd.linear.x = linear
        cmd.angular.z = angular
        turtle_vel.publish(cmd)
        rate.sleep()
